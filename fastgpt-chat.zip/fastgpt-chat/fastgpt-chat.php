<?php
/*
Plugin Name: FastGPT Chat
Description: Adds a FastGPT chatbot to your WordPress site.
Version: 1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Register shortcode [fastgpt_chat]
add_shortcode('fastgpt_chat', function() {
    return '
    <div id="fastgpt-chat" style="max-width:500px; margin:20px auto;">
        <input id="fg-input" placeholder="Ask FastGPT..." style="width:70%; padding:8px;" />
        <button id="fg-send" style="padding:8px;">Send</button>
        <pre id="fg-output" style="background:#f5f5f5; padding:10px; margin-top:10px;"></pre>
    </div>

    <script>
    document.getElementById("fg-send").addEventListener("click", async function() {
        const msg = document.getElementById("fg-input").value;
        if(!msg) return;
        document.getElementById("fg-output").textContent = "Thinking...";
        try {
            const res = await fetch("' . esc_url( get_rest_url(null, 'fastgpt/v1/chat') ) . '", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ message: msg })
            });
            const data = await res.json();
            document.getElementById("fg-output").textContent = data.reply || "No response";
        } catch(e) {
            document.getElementById("fg-output").textContent = "Error: " + e;
        }
    });
    </script>
    ';
});

// Register REST API route
add_action('rest_api_init', function () {
    register_rest_route('fastgpt/v1', '/chat', [
        'methods' => 'POST',
        'callback' => function ($req) {

            $user_message = sanitize_text_field($req['message'] ?? '');
            if (!$user_message) return ['reply' => 'Please send a message.'];

            $api_key = 'fastgpt-yB27YEOsv9DtiPAsjoa9CTHxoms1e2w2mc5SEtKbzayCny8BKpvQsbl2K'; // Replace with your FastGPT API key
            $endpoint = 'https://cloud.fastgpt.io/chat/share?shareId=xBpFfd5z8e3ty8je6fxY2wSk/api/v1/chat/completions'; // Replace with your FastGPT domain

            $body = json_encode([
                'messages' => [
                    ['role' => 'user', 'content' => $user_message]
                ]
            ]);

            $response = wp_remote_post($endpoint, [
                'headers' => [
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer ' . $api_key
                ],
                'body' => $body,
                'timeout' => 15
            ]);

            if (is_wp_error($response)) {
                return ['reply' => 'Error connecting to FastGPT: ' . $response->get_error_message()];
            }

            $data = json_decode(wp_remote_retrieve_body($response), true);

            if (isset($data['choices'][0]['message']['content'])) {
                return ['reply' => $data['choices'][0]['message']['content']];
            } else {
                return ['reply' => 'No response from FastGPT.'];
            }
        }
    ]);
});
